package information.retrievial;

import java.util.ArrayList;
import java.util.List;

public class jsonFinal {
	List <JsonResults> list= new ArrayList<JsonResults>();

	public List<JsonResults> getList() {
		return list;
	}

	public void setList(List<JsonResults> list) {
		this.list = list;
	}
	
	

}
